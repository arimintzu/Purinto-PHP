<?php
$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.pdfshift.io/v2/convert/",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(array("source" => "https://purinto.thekingcorp.org/admin/pages/memberprint.php", "landscape" => true, "use_print" => false)),
    CURLOPT_HTTPHEADER => array('Content-Type:application/json'),
    CURLOPT_USERPWD => '81104a8d376c4c3aa50778d11bbd2b9c'
));

$response = curl_exec($curl);
file_put_contents('report/DataMember.pdf', $response);
echo '<script type= "text/javascript">window.location.href = "report/DataMember.pdf";</script>';
?>
